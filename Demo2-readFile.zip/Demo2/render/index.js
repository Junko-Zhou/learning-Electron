var fs=require('fs')//WebPreferences的作用：允许引用
window.onload=function(){
    //获取html里的组件
    var btn =this.document.querySelector('#btn1')
    var breads=this.document.querySelector('#breads')
    //当按键被点击
    btn.onclick=function(){
        //读取文件，并且执行：
        fs.readFile('Bakery.txt',(err,data)=>{
            //将读取内容(data)赋值(innerHTML)给breads(div组件)
            breads.innerHTML=data
        })
    }
}