var electron=require('electron')

var app =electron.app//引用app属性
var BrowserWindow=electron.BrowserWindow//窗口控制引用

var mainWindow=null//主窗口（相当于一个对象）
//on:监控
app.on('ready',()=>{
    mainWindow=new BrowserWindow({
        width:500,height:500,
        webPreferences:{
            enableRemoteModule:true,
            nodeIntegration:true
        }
    })
    mainWindow.loadFile('index.html')//加载页面ui：启动渲染进程
    mainWindow.on('closed',()=>{
        mainWindow=null
    })
})