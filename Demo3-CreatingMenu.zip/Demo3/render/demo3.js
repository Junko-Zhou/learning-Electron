const {remote}=require('electron')
const BrowserWindow=remote.BrowserWindow


const btn1=this.document.querySelector('#btn1')
window.onload=function(){
    
    btn1.onclick=()=>{
        newWin=new BrowserWindow({width:500,height:500})
        newWin.loadFile('child.html')
        newWin.on('close',()=>{
            newWin=null
        })
    }
}
//Menu是主进程下的，所以需要remote。
const {remote}=require('electron')

//建立菜单模板
var rTemplate = [
    {label:'粘贴'},
    {label:'复制'}
]
//建立菜单
var rm=remote.Menu.buildFromTemplate(rTemplate)

window.addEventListener('contextmenu',function(e){
    e.preventDefault()//阻止默认响应事件
    rm.popup({window:remote.getCurrentWindow()})//弹出菜单
})