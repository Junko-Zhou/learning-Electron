const {Menu, BrowserWindow} = require('electron')//引入BrowserWindow

var template = [
    {
        label:'刺身料理餐厅',
        submenu:[
            {
                label:'北极贝',
                accelerator:'ctrl+b',
                //对click事件做反应
                click:()=>{
                    var bjbWin = new BrowserWindow({
                        width:500,height:500,
                        webPreferences:{nodeIntegration:true}
                    })
                    bjbWin.loadFile('beijibei.html')
                    bjbWin.on('close',()=>{
                        bjbWin=null
                    })
                }
            },
            {label:'三文鱼大腩'}
        ]
    },
    {
        label:'日式家庭餐厅',
        submenu:[
            {label:'猪排饭'},
            {label:'荞麦面'}
        ]
    }
]

var m = Menu.buildFromTemplate(template)
Menu.setApplicationMenu(m)