var electron=require('electron')
var app=electron.app
var BrowserWindow=electron.BrowserWindow
var mainWin=null
app.on('ready',()=>{
    mainWin=new BrowserWindow({
        width:500,
        height:500,
        webPreferences:{
            nodeIntegration:true,
            enableRemoteModule:true
        }
    })
    mainWin.webContents.openDevTools()
    require('./littlethings/menu.js')
    mainWin.loadFile('demo3.html')
    mainWin.on('close',()=>{
        mainWin=null
    })
})

